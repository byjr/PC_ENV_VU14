#ifndef _CURL_PUSH_H
#define _CURL_PUSH_H
#include <curl/curl.h>
class curlPushCliPar{
public:	
	char *dstPath;
	char *srcPath;	
};
class curlPushCli{
	curlPushCliPar *mPar;
public:	
	curlPushCli(curlPushCliPar * par){
		mPar = par;
		//curl_global_init();		
	}
	curlPushCli(){
		
	}
};
#endif